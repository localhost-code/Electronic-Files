/************************************************************************\
*  Crackerhack Version 2.0 (c) 1992 by No Means No.  Released 11/1/1992  *
*------------------------------------------------------------------------*
* [SETCH.C]: Setup crackerhack source code. Used to specify the password *
* you want to crack and how you want to crack it.  This program creates  *
* the [.ch-d] data file used by all other Crackerhack programs. Read the *
* Crackerhack documentation file for more information.                   *
\************************************************************************/
#include <stdio.h>
#include <fcntl.h>
FILE *fp;
char targusr[20],targ[14],strstart[10],strfinish[10];
char num[10],ALP[26],alp[26],mode[2],ch[2];
 
main() {
  printf("\n\n--> Setup program for Crackerhack Version 2 <--\n");
  printf("(1): Choose your target from the \042/etc/passwd\042 file\n");
  printf("(2): Choose your target from the \042.ch-p\042 file\n");
  printf("(3): Manually enter the encrypted password string\n");
  printf("Select: ");
  gets(ch);
  printf("\n");
  switch(ch[0])
    { case '1': choose("/etc/passwd"); break;
      case '2': choose(".ch-p"); break;
      case '3': manual(); break;
      default : printf("Aborted.\n\n"); }
}

choose(file) char file[20]; {
char x[4],sys[80],y;
long yy;
int done_flag=0;
  printf("Choosing a target from file: %s\n",file);
  printf("Enter full or partial name to scan for: ");
  gets(targusr);
  if(strlen(targusr)>0) {
    strcpy(sys,"grep ");
    strcat(sys,targusr);
    strcat(sys," "); strcat(sys,file);
    strcat(sys," >.ch-t");
    system(sys);
  }
  else {
    strcpy(sys,"cp ");
    strcat(sys,file);
    strcat(sys," .ch-t");
    system(sys);
  }
  if((fp=fopen(".ch-t","r"))==NULL||feof(fp)) {
    printf("No matches found.\n\n");
  }
  else {
    rewind(fp); y=0;
    while(!done_flag) {
      fscanf(fp,"%[^:]%*c%[^:]",targusr,targ);
      while(!feof(fp)&&(y=fgetc(fp))!='\n');
      y=fgetc(fp);
      if(!feof(fp)) fseek(fp,-1,1);
      else done_flag=1;
      printf("Target [%s:%s] correct? <y/N/q>:",targusr,targ);
      gets(x); if(!strncmp(x,"y",1)||!strncmp(x,"q",1)) done_flag=1;
    }
    fclose(fp);
    system("rm -f .ch-t");
    if(strncmp(x,"y",1)) printf("No target specified.\n\n");
    else range();
  }
}

manual() {
  printf("Enter the encrypted password in its EXACT form: ");
  gets(targ);
  strcpy(targusr,"(Manual_Entry)");
  range();
}

range() {
  strcpy(num,"0123456789");
  strcpy(ALP,"ABCDEFGHIJKLMNOPQRSTUVWXYZ");
  strcpy(alp,"abcdefghijklmnopqrstuvwxyz");
  printf("Target: %s\nPasswd: %s\n\n",targusr,targ);
  printf("Select one of the following COMBINATIONS:\n");
  printf("(1): %s\n",num);
  printf("(2): %s\n",alp);
  printf("(3): %s%s\n",num,alp);
  printf("(4): %s%s\n",ALP,alp);
  printf("(5): %s%s%s\n",num,ALP,alp);
  printf("Select (1-5): ");
  gets(mode);
  printf("\nNow select the cracking RANGE, up to 8 characters.\n");
  printf("From  : "); gets(strstart);
  printf("To    : "); gets(strfinish);
  system("rm -f .ch-d");
  fp=fopen(".ch-d","w");
  fprintf(fp,"%s\n%s\n%s\n%s\n%s\n",targusr,targ,strstart,strfinish,mode);
  fclose(fp);
  printf("\n\n-> Your Crackerhack [.ch-d] data file has been written.\n");
  printf("-> You are now ready to run Crackerhack version 2.0.\n");
  printf("-> Crackerhack should be run as a BACKGROUND job...\n");
  printf("-> This can be done by typing 'nohup ch &' on a unix.\n");
  printf("-> It is a good idea to run TIMECH to get a good estimate\n");
  printf("-> of how long this crack will take to complete.\n\n");
}
