/************************************************************************\
*  Crackerhack Version 2.0 (c) 1992 by No Means No.  Released 11/1/1992  *
*------------------------------------------------------------------------*
* [TIMECH.C]: Time Crackerhack source code.  Loads the Crackerhack data  *
* file [.ch-d] (set with SETCH), and calculates the estimated amount of  *
* time Crackerhack will take to complete its cracking scan.  Read the    *
* Crackerhack documentation for more information.                        *
\************************************************************************/
#include <stdio.h>
#include <ctype.h>
#include <fcntl.h>
#ifdef __hp9000
# include <string.h>
#else
# include <strings.h>
#endif
#include <sys/time.h>
#include <sys/resource.h>
#include "addch.h"
char *crypt();
 
main() {
struct timeval start;
struct timeval stop;
FILE *fp;
char targusr[20],targ[15],strstart[10],strfinish[10],tmp_start[10];
int mode;
float num;
double c,begin,end,seconds,minutes,hours,days,years;
  if((fp=fopen(".ch-d","r"))!=NULL) {
    fscanf(fp,"%s\n%s\n%s\n%s\n%d\n",targusr,targ,strstart,strfinish,&mode);
    fclose(fp);
  }
  else {
    fclose(fp);
    printf("Can not find [.ch-d] data file!  Use SETCH before TIMECH.\n");
    exit(0);
  }
  printf("\n\nTime CrackerHack: Please wait 10 seconds...\n");
  printf("Calculating number of crypts per second...\n\n");
  gettimeofday(&start,(struct timezone *)NULL);
  begin=(((start.tv_sec*1000.)+(start.tv_usec/1000)))+10000.; end=0;
  while(begin>end) {
    crypt("test","crypt");
    gettimeofday(&stop,(struct timezone *)NULL);
    end=((stop.tv_sec*1000.)+(stop.tv_usec/1000));
    num++;
  }
  printf("Crypts in 10 secs: %f\n",num);
  printf("Crypts per second: %f\n",(num/=10));
  strcpy(tmp_start,strstart);
  c=count_ch(strstart,strfinish,mode);
  printf("Cracking range   : (%s->%s)\n",tmp_start,strfinish);
  printf("Total crypts made: %.0f\n",c);
  printf("Total seconds    : %f\n",(seconds=c/num));
  printf("Total time       : ");
  if(seconds>59) { minutes=seconds/60;
    seconds=(int)((long int)seconds-((long int)minutes*60));
    if(minutes>59) { hours=minutes/60;
      minutes=(int)((long int)minutes-((long int)hours*60));
      if(hours>23)   { days=hours/24;
        hours=(int)((long int)hours-((long int)days*24));
        if(days>355)   { years=days/356;
          days=(int)((long int)days-((long int)years*356));
        }
      }
    }
  }
  if(years) printf("%d years. ",(int)years);
  if(days) printf("%d days. ",(int)days);
  if(hours) printf("%d hours. ",(int)hours);
  if(minutes) printf("%d minutes. ",(int)minutes);
  if(seconds) printf("%d seconds.",(int)seconds);
  printf("\n\nSuggestion: ");
  if(!years&&!days) printf("Looks good to me, crack it!\n");
  else if(!years&&days<=7) printf("Try a faster machine or encryption.\n");
  else if(!years&&days>7) printf("Use NETCH for this crack!\n");
  else printf("I don't think so!\n");
  printf("Crackerhack V2 time analyzation complete.\n\n\n");
}
