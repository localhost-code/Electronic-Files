/************************************************************************\
*   Crackerhack Version 2.0 (c) 1992 by No Means No.  Released 11/1/92   *
*------------------------------------------------------------------------*
* [NETCH.C]: Split CrackerHack into multiple jobs then send them to be   *
* be cracked by different systems over the network that you have access  *
* to using rsh command.  This program uses the [.ch-d] data file (set by *
* SETCH) and the [.ch-n] network system data file (read CH2-NET file).   *
* NETCH is totally automatic, read CH2-DOC for information on setting    *
* the [.ch-n] network system access specification file. Read Crackerhack *
* documentation file for more information on using NETCH.                *
\************************************************************************/
#include <stdio.h>
#if defined(sun) || defined(__hp9000)
# include <varargs.h>
  char *multicat();
#else
# include <stdarg.h>
  char *multicat(int i,...);
#endif
#include "addch.h"
#define SPLITMAX 100
FILE *fp;
char str[SPLITMAX+1][10],prog[20],network[SPLITMAX][6][80],rshcmd[40];
int jobs,j,cmd,ln;
char *get_line();
char *pull_from();
char *i_to_c();

main(argc,argv) int argc; char *argv[]; {
char line[255];
int x;
  ln=0;
  strcpy(prog,argv[0]);
  if((fp=fopen(".ch-n","r"))==NULL) netch_error(1,"");
  rewind(fp);
  if(argc==1) strcpy(rshcmd,"rsh");
  else printf("Using %s\n",strcpy(rshcmd,argv[1]));
  while(1) {
    strcpy(line,get_line());
    if(line[0]=='0'||(j==jobs&&j>0)) break;
    if(!strncmp(line,"(",1)) {
      x=1;
      while(isdigit(line[x])) { line[x-1]=line[x]; x++; }
      line[x-1]='\0';
      jobs=atoi(line);
      if(jobs<2||jobs>SPLITMAX) netch_error(2,line);
    }
    else if(!strncmp(line,"#",1)) {
      if(jobs==0) netch_error(3,line);
      for(cmd=0;cmd<6;cmd++) {
        strcpy(line,pull_from(line,network[j][cmd]));
        if(!strcmp(network[j][cmd],"^")) {
          if(j==0) netch_error(4,line);
          else strcpy(network[j][cmd],network[j-1][cmd]);
        }
        else if(!strcmp(network[j][cmd],".")) network[j][cmd][0]='\0';
      }
      j++;
    }
  }
  if(jobs==0&&j==0) netch_error(5,"");
  if(j==0||j<jobs) netch_error(6,"");
  fclose(fp);
  if(!netsplit_crackerhack()) {
    printf("%s: Can not open [.ch-d] datafile, use SETCH first.\n",prog);
  }
}

char *get_line() {
char x,data[255];
int i=0;
  while(1) {
    if((data[i]=fgetc(fp))!='('&&data[i]!='#') {
      while(!feof(fp)&&(x=fgetc(fp))!='\n'); i=0; if(x=='\n') ln++;
    } 
    else {
      i++;
      while(!feof(fp)&&(x=fgetc(fp))!='\n') data[i++]=x;
      if(x=='\n') ln++;
      data[i]='\0'; return(data);
    }
    if(feof(fp)) return("0");
  }
}

char *pull_from(from,into) char from[255],into[255]; {
char new[255];
int f=0,i=0,n=0;
  while(1) {
    if(i==0&&(from[f]=='#'||from[f]==' ')) f++;
    else if(from[f]=='#') break;
    else into[i++]=from[f++];
  }
  into[i]='\0';
  while(f<strlen(from)) new[n++]=from[f++];
  new[n]='\0';
  return(new);
}

netch_error(num,where) int num; char *where; {
  static char *er[]={
    "Network information file [.ch-n] not found.",
    "^---Illegal number of network splits.",
    "^---Arguments declared before the number of splits was stated.",
    "^---No previous argument to replace with ^.",
    "No network information specified in [.ch-n].",
    "Network information file [.ch-n] not complete, please examine it." };
  if(!strlen(where)) printf("\n%s: %s\n\n",prog,er[num-1]);
  else printf("\n%s: %s (Line #%d)\n%s: %s\n\n",prog,where,ln,prog,er[num-1]);
  fclose(fp);
  exit(0);
}

netsplit_crackerhack() {
char targusr[20],targ[15],strstart[10],strfinish[10],rshout[255],modechar[4];
int  i,o,t,tt,x,xx,mode,j,y,neterrs,inc[11],tmp[11];
double c,num;
  if((fp=fopen(".ch-d","r"))==NULL) {
    fclose(fp);
    return 0;
  }
  fscanf(fp,"%s\n%s\n%s\n%s\n%d\n",targusr,targ,strstart,strfinish,&mode);
  fclose(fp);
  printf("%s: Splitting [%s->%s] into %d jobs and networking...\n"
         ,prog,strstart,strfinish,jobs);
  strcpy(str[0],strstart);
  c=count_ch(strstart,strfinish,mode);
  num=(int)(c/(double)(float)jobs);
  t=0;
  for(y=9;y>=0;y--) {
    x=y>0?power(n,y):1;
    inc[t]=0;
    if((num/x)>1) {
      inc[t]=(int)(float)(num/x);
      num-=((double)(float)(inc[t])*x);
    }
    t++;
  }
  xx=0; while(inc[xx]==0) xx++;
  for(j=0;j<jobs;) {
    strcpy(str[j+1],str[j]);
    j++;
    y=strlen(str[j]);
    for(x=10;x>=0;x--) tmp[x]=inc[x];
    for(x=10;x>=0;x--) {
      if(y<0&&x>=xx) {
        for(y=strlen(str[j]);y>=0;y--) str[j][y+1]=str[j][y];
        y=0; str[j][y]=s; tmp[x]--;
      }
      while(tmp[x]>0) {
        if(mode==3) while((!isalnum(++str[j][y])||isupper(str[j][y]))
                           &&(f>str[j][y]));
        else while(!isalnum(++str[j][y])&&(f>str[j][y]));
        if(str[j][y]>f) {
          tmp[x-1]++; str[j][y]=s;
          if((x-1)<xx) xx--;
        }
        tmp[x]--;
      }
      y--;
    }
  }
  strcpy(str[j],strfinish);
  for(j=1,neterrs=0;j<=jobs;j++) {
    printf("\n%s: Networking job #%d [%s->%s] under %s@%s\n",
           prog,j,str[j-1],str[j],network[j-1][0],network[j-1][1]);
    strcpy(modechar,i_to_c(mode));
    strcpy(rshout,multicat(22,
      rshcmd," ",network[j-1][1]," -l ",network[j-1][0]," \042cd ",
      network[j-1][2],";",network[j-1][3],";",network[j-1][4],";",
      network[j-1][5],";netch.sh -n ",targ," ",str[j-1]," ",str[j],
      " ",modechar,"\042"));
    if(system(rshout)) {
      printf("  ->NETWORK FAIL! Error #%d.\n",++neterrs);
      printf("  ->%s\n",rshout);
    }
    else printf("  ->Successfully networked.\n");
  }
  printf("\nNetwork Crackerhack complete with %d errors.\n",neterrs);
  return 1;
}

#if defined(_sys_varargs_h) || defined(_SYS_VARARGS_H) || \
    defined(_VARARGS_INCLUDED)
  char *multicat(i,va_alist) int i; va_dcl {
  char total[500]; va_list argptr; va_start(argptr);
#else
  char *multicat(int i,...) {
  char total[500]; va_list argptr; va_start(argptr,i);
#endif
  for(total[0]='\0';i;i--) strcat(total,va_arg(argptr,char *));
  va_end(argptr);
  return(total);
}

char *i_to_c(in) int in; {
char out[10];
int n,p,t,x;
  for(out[0]='\0',n=0,x=10;x>=0;x--) { p=x>0?power(10,x):1;
    if((in/p)>=1||n) { t=in/p;
      out[n++]=t+48; in-=(t*p);
    }
  }
out[n]='\0';
return(out);
}
