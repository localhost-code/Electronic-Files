/************************************************************************\
*  Crackerhack Version 2.0 (c) 1992 by No Means No.  Released 11/1/1992  *
*------------------------------------------------------------------------*
* [CH.C]: CrackerHack file source code. Increment fast password cracker. *
* Uses [.ch-d] Crackerhack data file which is set by the SETCH program.  *
* Read Crackerhack documentation for information.                        *
\************************************************************************/
#include <stdio.h>
#if defined(sun) || defined(__hp9000)
# include <sys/varargs.h>
#else
# include <stdarg.h>
  void chlog(int i,...);
#endif
#include <ctype.h>
#include <fcntl.h>
#ifdef __hp9000
# include <string.h>
#else
# include <strings.h>
#endif
#include <signal.h>
#include <sys/time.h>
#include <sys/resource.h>
#ifdef __hp9000
#define HIPRIO() syscall(setpriority,PRIO_PROCESS,0,PRIO_MIN)
#define NOPRIO() syscall(setpriority,PRIO_PROCESS,0,0)
#elif CRAY
#define HIPRIO() nice(-20)
#define NOPRIO() nice(0)
#else
#define HIPRIO() setpriority(PRIO_PROCESS,0,PRIO_MIN)
#define NOPRIO() setpriority(PRIO_PROCESS,0,0)
#endif
struct timeval start;
struct timeval stop;
FILE	*fp;
char targusr[20],targ[15],strstart[10],strfinish[10],try[10],s,f;
int mode,found;
double c;
char *crypt();
void chabort();
char *d_to_c();
double power();
 
main(argc,argv) int argc; char *argv[]; {
  signal(SIGHUP,chabort);    signal(SIGINT,chabort);
  signal(SIGTSTP,chabort);   signal(SIGQUIT,chabort);
  if(argc==6) {
    if(!strcmp(argv[1],"-n")) strcpy(targusr,"(NETCH)");
    else strcpy(targusr,"(SPLITCH)");
    strcpy(targ,argv[2]);
    strcpy(strstart,argv[3]);
    strcpy(strfinish,argv[4]);
    mode=atoi(argv[5]);
  }
  else {
    if((fp=fopen(".ch-d","r"))!=NULL) {
      fscanf(fp,"%s\n%s\n%s\n%s\n%d\n",targusr,targ,strstart,strfinish,&mode);
      fclose(fp);
    }
    else {
      fclose(fp);
      printf("Crackerhack v2 Aborted! Read [.ch-l] log!\n");
      chlog(1,"File [.ch-d] nonexistant! Use SETCH prior to using CH!");
      done();
    }
  }
  chlog(6,"Attacking ",targusr,": ",strstart,"->",strfinish);
  HIPRIO(); crack(); NOPRIO();
  if(!found) chlog(1,"Could not crack password within given combo/range.");
  else chlog(4,"CRACKED PASSWORD FOR ",targusr,": ",try);
  info();
}

crack() {
register char *match;
int t,x,m;
  switch(mode)
    { case 1 : s='0'; f='9'; break;
      case 2 : s='a'; f='z'; break;
      case 3 : s='0'; f='z'; break;
      case 4 : s='A'; f='z'; break;
      default: s='0'; f='z'; break; }
  found=0; c=0; strcpy(try,strstart);
  gettimeofday(&start,(struct timezone *)NULL);
  while(strcmp(try,strfinish)&&found==0) {
    c++;
    if(!strcmp(match=crypt(try,targ),targ)) found=1;
    else {
      t=strlen(try)-1; x=t; m=0;
      while(m==0) {
        if(mode==3) while((!isalnum(++try[x])||isupper(try[x]))&&(f>try[x]));
        else while(!isalnum(++try[x])&&(f>try[x]));
        if(try[x]<=f) m=1;
        else {
          try[x]=s; x--;
	       if(x<0) { try[++t]=s; try[++t]='\0'; m=1; }
        }
      }
    }
  }
  gettimeofday(&stop,(struct timezone *)NULL);
}

#if defined(_sys_varargs_h) || defined(_SYS_VARARGS_H) || \
    defined(_VARARGS_INCLUDED)
  chlog(i,va_alist) int i; va_dcl {
  char x; va_list argptr; va_start(argptr);
#else
  void chlog(int i,...) {
  char x; va_list argptr; va_start(argptr,i);
#endif
  while((fp=fopen(".ch-l","a+"))==NULL);
  fprintf(fp,"|CrackerHack| ");
  for(;i;i--) fprintf(fp,"%s",va_arg(argptr,char *));
  fprintf(fp,"\n");
  fclose(fp);
  va_end(argptr);
}

info() {
double sec;
char tmp[11];
  sec=(((stop.tv_sec*1000.)+(stop.tv_usec/1000))-
      ((start.tv_sec*1000.)+(start.tv_usec/1000)))/1000.;
  chlog(6,"Target (",targusr,"): ",strstart,"->",strfinish);
  strcpy(tmp,d_to_c(sec)); chlog(2,"Total time in seconds: ",tmp);
  strcpy(tmp,d_to_c(c)); chlog(2,"Total encryptions    : ",tmp);
  strcpy(tmp,d_to_c(c/sec)); chlog(2,"Total encryptions/sec: ",tmp);
  done();
}

char *d_to_c(num) double num; {
char str[20];
double p,t,left,right;
int x,y=0;
  left=(int)num; right=num-left;
  for(x=10;x>=0;x--) { p=x>0?power(10,x):1;
    if((left/p)>=1||y) { t=(int)(float)(left/p);
      str[y++]=t+48; left-=(t*p);
    }
  }
  str[y++]='.';
  for(x=1;(int)(right*1000000);x++) {
    p=power(10,x); t=(int)(float)(right*p);
    str[y++]=t+48; right-=(t/p);
  }
  str[y]='\0';
  if(str[--y]=='.') str[y]='\0';
  if(y==0) str[y]='0';
  return(str);
}

double power(x,y) int x,y; {
unsigned long int i;
  if(y==0) return (double)0;
  for(i=x;y>1;y--) i=(i*x); return i;
}

done() {
  chlog(1,"+----------------------------------------+");
  exit(0);
}

void chabort() {
  gettimeofday(&stop,(struct timezone *)NULL);
  chlog(2,"*ABORTED* Last crypt was: ",try);
  info();
}
