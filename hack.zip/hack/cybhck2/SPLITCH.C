/************************************************************************\
*  Crackerhack Version 2.0 (c) 1992 by No Means No.  Released 11/1/1992  *
*------------------------------------------------------------------------*
* [SPLITCH.C]:  Split CrackerHack into multiple jobs!  Can split it into *
* as many as 10 jobs on the same machine.  Uses data file [.ch-d] which  *
* is set by the SETCH program.  Read the Crackerhack documentation for   *
* more information.                                                      *
\************************************************************************/
#include <stdio.h>
#if defined(sun) || defined(__hp9000)
# include <varargs.h>
  char *multicat();
#else
# include <stdarg.h>
  char *multicat(int i,...);
#endif
#include "addch.h"
#define SPLITMAX 10
#define BEFORECH "nohup"
#define AFTERCH "&"
FILE *fp;
char str[SPLITMAX+1][10],prog[20];
int jobs;
char *i_to_c();

main(argc,argv) int argc; char *argv[]; {
  strcpy(prog,argv[0]);
  if(argc<2||argc>2) printf("Usage: %s <# of jobs>\n",prog);
  else if((jobs=atoi(argv[1]))<2||jobs>SPLITMAX) {
    printf("%s: Between 2 and %d jobs please!\n",prog,SPLITMAX);
  }
  else {
    if(!split_crackerhack()) {
      printf("%s: Can not open [.ch-d] datafile, use SETCH first!\n",prog);
    }
  }
}

split_crackerhack() {
char targusr[20],targ[15],strstart[10],strfinish[10],modechar[2],bgjob[200];
int i,o,t,tt,x,xx,mode,j,y,inc[11],tmp[11];
double c,num;
  if((fp=fopen(".ch-d","r"))==NULL) {
    fclose(fp);
    return 0;
  }
  fscanf(fp,"%s\n%s\n%s\n%s\n%d\n",targusr,targ,strstart,strfinish,&mode);
  fclose(fp);
  printf("%s: Splitting [%s->%s] into %d jobs...\n",
         prog,strstart,strfinish,jobs);
  strcpy(str[0],strstart);
  c=count_ch(strstart,strfinish,mode);
  num=(int)(c/(double)(float)jobs);
  for(t=0,y=9;y>=0;y--) {
    x=y>0?power(n,y):1;
    if((num/x)>1) {
      inc[t]=(int)(float)(num/x);
      num-=((double)(float)(inc[t])*x);
    }
    t++;
  }
  xx=0; while(inc[xx]==0) xx++;
  for(j=0;j<jobs;) {
    strcpy(str[j+1],str[j]);
    j++;
    y=strlen(str[j]);
    for(x=10;x>=0;x--) tmp[x]=inc[x];
      for(x=10;x>=0;x--) {
        if(y<0&&x>=xx) {
          for(y=strlen(str[j]);y>=0;y--) str[j][y+1]=str[j][y];
          y=0; str[j][y]=s; tmp[x]--;
        }
      while(tmp[x]>0) {
        if(mode==3) while((!isalnum(++str[j][y])||isupper(str[j][y]))
                         &&(f>str[j][y]));
        else while(!isalnum(++str[j][y])&&(f>str[j][y]));
        if(str[j][y]>f) {
          tmp[x-1]++; str[j][y]=s;
          if((x-1)<xx) xx--;
        }
        tmp[x]--;
      }
      y--;
    }
  }
  strcpy(str[j],strfinish);
  for(j=1;j<=jobs+1;j++) {
    if(j!=jobs+1) {
      strcpy(modechar,i_to_c(mode));
      strcpy(bgjob,multicat(11,BEFORECH," ch -s ",targ," ",str[j-1],
                               " ",str[j]," ",modechar," ",AFTERCH));
      system(bgjob);
      printf("%s: Executed job #%d: [%s->%s]\n",prog,j,str[j-1],str[j]);
    }
     else printf("%s: All jobs have been executed. Complete.\n",prog);
  }
  return 1;
}

#if defined(_sys_varargs_h) || defined(_SYS_VARARGS_H) || \
    defined(_VARARGS_INCLUDED)
  char *multicat(i,va_alist) int i; va_dcl {
  char total[500]; va_list argptr; va_start(argptr);
#else
  char *multicat(int i,...) {
  char total[500]; va_list argptr; va_start(argptr,i);
#endif
  for(total[0]='\0';i;i--) strcat(total,va_arg(argptr,char *));
  va_end(argptr);
  return(total);
}

char *i_to_c(in) int in; {
char out[10];
int n,p,t,x;
  for(out[0]='\0',n=0,x=10;x>=0;x--) { p=x>0?power(10,x):1;
    if((in/p)>=1||n) { t=in/p;
      out[n++]=t+48; in-=(t*p);
    }
  }
out[n]='\0';
return(out);
}
